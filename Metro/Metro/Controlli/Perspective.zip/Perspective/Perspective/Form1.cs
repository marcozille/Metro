﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace Perspective
{
    public partial class Form1 : Form
    {
        private Bitmap _bmp = null;
        private float _zoom = 1.0F;
        private bool _pic_changed = false;

        public Form1()
        {
            InitializeComponent();
        }

        public Form1(string[] args)
        {
            InitializeComponent();
            if (args.Length > 0)
            {
                try
                {
                    Image img = Image.FromFile(args[0], false);
                    _bmp = new Bitmap(img);
                    img.Dispose();

                    this._pic_changed = false;
                    this.Text = args[0];
                    this._zoom = 1.0F;
                    this.panel2.AutoScrollMinSize = new Size((int)(_bmp.Width * _zoom), (int)(_bmp.Height * _zoom));
                    this.panel2.Invalidate();

                    this.numericUpDown1.Value = (decimal)_bmp.Width;
                    this.numericUpDown2.Value = (decimal)_bmp.Height;
                }
                catch
                {

                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (_pic_changed)
            {
                DialogResult dlg = MessageBox.Show("Bild erst noch speichern?", "Ungespeichert Daten",
                    MessageBoxButtons.YesNoCancel, MessageBoxIcon.Exclamation);

                if (dlg == DialogResult.Yes)
                {
                    button2.PerformClick();
                }
                else if (dlg == DialogResult.No)
                    _pic_changed = false;
            }

            if (!_pic_changed)
            {
                if (this.openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        Image img = Image.FromFile(this.openFileDialog1.FileName, false);
                        if (_bmp != null)
                            _bmp.Dispose();
                        _bmp = new Bitmap(img);
                        img.Dispose();

                        this.numericUpDown1.Value = (decimal)_bmp.Width;
                        this.numericUpDown2.Value = (decimal)_bmp.Height;

                        this._pic_changed = false;
                        this.Text = this.openFileDialog1.FileName;
                        this._zoom = 1.0F;
                        this.panel2.AutoScrollMinSize = new Size((int)(_bmp.Width * _zoom), (int)(_bmp.Height * _zoom));
                        this.panel2.Invalidate();
                    }
                    catch
                    {

                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (_bmp != null)
            {
                try
                {
                    if (this.saveFileDialog1.ShowDialog() == DialogResult.OK)
                    {
                        _bmp.Save(this.saveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Png);
                        _pic_changed = false;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (this.comboBox1.SelectedIndex == 0)
            {
                if (_bmp != null)
                {
                    this.Cursor = Cursors.WaitCursor;
                    Application.DoEvents();

                    PerspectiveModus pm = (PerspectiveModus)Enum.Parse(typeof(PerspectiveModus), this.comboBox2.SelectedItem.ToString());

                    if (this.CheckBox1.Checked)
                    {
                        Bitmap bmp2 = null;
                        FloatPointF[,] fp = null;
                        Bitmap img2 = null;
                        Graphics g = null;

                        try
                        {
                            bmp2 = (Bitmap)_bmp.Clone();

                            if (pm == PerspectiveModus.HorizontalDownMode2)
                            {
                                bmp2.RotateFlip(RotateFlipType.RotateNoneFlipX);
                            }
                            else if (pm == PerspectiveModus.HorizontalUpMode2)
                            {
                                //Nothing here
                            }
                            else if (pm == PerspectiveModus.VerticalDownMode2)
                            {
                                bmp2.RotateFlip(RotateFlipType.Rotate90FlipNone);
                            }
                            else if (pm == PerspectiveModus.VerticalUpMode2)
                            {
                                bmp2.RotateFlip(RotateFlipType.Rotate270FlipNone);
                            }

                            //doit

                            int nWidth = bmp2.Width;
                            int nHeight = bmp2.Height;

                            fp = new FloatPointF[nWidth, nHeight];

                            double xval = (double)this.numericUpDown9.Value;

                            //Parallel.For(0, nWidth, x =>
                            for(int x = 0; x < nWidth; x++)
                            {
                                for (int y = 0; y < nHeight; y++)
                                {
                                    double newX = Math.Min(nWidth, ((double)nWidth * Math.Pow((double)x / (double)nWidth, 1.0 / xval)));

                                    if (newX > 0 && newX < nWidth)
                                    {
                                        fp[x, y].X = (float)newX;
                                    }
                                    else
                                    {
                                        fp[x, y].X = 0.0F;
                                    }

                                    double newY = y;

                                    if (newY > 0 && newY < nHeight)
                                    {
                                        fp[x, y].Y = (float)newY;
                                    }
                                    else
                                    {
                                        fp[x, y].Y = 0.0F;
                                    }
                                }
                            }//);

                            fipbmp.OffsetFiAntiAlias(bmp2, fp);

                            //restretch 1/faktor
                            int newWidth = (int)Math.Ceiling((1.0D / xval) * nWidth);
                            img2 = new Bitmap(newWidth, nHeight);
                            g = Graphics.FromImage(img2);
                            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                            g.DrawImage(bmp2, 0, 0, newWidth, nHeight);
                            g.Dispose();

                            bmp2.Dispose();
                            bmp2 = img2;

                            if (pm == PerspectiveModus.HorizontalDownMode2)
                            {
                                bmp2.RotateFlip(RotateFlipType.RotateNoneFlipX);
                            }
                            else if (pm == PerspectiveModus.HorizontalUpMode2)
                            {
                                //Nothing here
                            }
                            else if (pm == PerspectiveModus.VerticalDownMode2)
                            {
                                bmp2.RotateFlip(RotateFlipType.Rotate270FlipNone);
                            }
                            else if (pm == PerspectiveModus.VerticalUpMode2)
                            {
                                bmp2.RotateFlip(RotateFlipType.Rotate90FlipNone);
                            }

                            _bmp.Dispose();
                            _bmp = bmp2;
                        }
                        catch
                        {
                            if(bmp2 != null)
                                bmp2.Dispose();
                            if ( fp != null)
                                fp = null;
                            if( img2 != null)
                                img2.Dispose();
                            if( g != null)
                                g.Dispose();
                            MessageBox.Show("Fehler.");
                            return;
                        }
                    }

                    float shortsideLength = 0;

                    if (pm == PerspectiveModus.HorizontalDownMode2 || pm == PerspectiveModus.HorizontalUpMode2)
                        shortsideLength = (float)this.numericUpDown2.Value;
                    else
                        shortsideLength = (float)this.numericUpDown1.Value;

                    float pts12Add = 0F;
                    float pts03Add = 0F;

                    if ((int)pm < 6)
                    {
                        pts12Add = (float)this.numericUpDown4.Value;
                        pts03Add = (float)this.numericUpDown5.Value;
                    }
                    else
                    {
                        pts12Add = (float)this.numericUpDown5.Value;
                        pts03Add = (float)this.numericUpDown4.Value;
                    }

                    Bitmap bmp = null;

                    try
                    {
                        if (pm == PerspectiveModus.HorizontalDownMode2 || pm == PerspectiveModus.HorizontalUpMode2)
                        {
                            if (shortsideLength > _bmp.Height)
                            {
                                float longsideLength = shortsideLength;
                                shortsideLength = _bmp.Height;
                                PointF[] pts = new PointF[4];
                                double v = (longsideLength - shortsideLength) / 2.0D;
                                if (pm == PerspectiveModus.HorizontalDownMode2)
                                {
                                    pts[3] = new PointF(0, _bmp.Width);
                                    pts[2] = new PointF(longsideLength, _bmp.Width);
                                    pts[0] = new PointF((float)v, 0);
                                    pts[1] = new PointF(longsideLength - (float)v, 0);
                                }
                                else
                                {
                                    pts[0] = new PointF(0, _bmp.Width);
                                    pts[1] = new PointF(longsideLength, _bmp.Width);
                                    pts[3] = new PointF((float)v, 0);
                                    pts[2] = new PointF(longsideLength - (float)v, 0);
                                }
                                if (pm == PerspectiveModus.HorizontalDownMode2)
                                    _bmp.RotateFlip(RotateFlipType.RotateNoneFlipX);
                                bmp = fipbmp.PerspectiveMode2(_bmp, pm, shortsideLength, longsideLength, true, true, pts12Add, pts03Add, pts);
                                if (pm == PerspectiveModus.HorizontalDownMode2)
                                    bmp.RotateFlip(RotateFlipType.RotateNoneFlipX);
                            }
                            else
                                bmp = fipbmp.PerspectiveMode2(_bmp, pm, shortsideLength, true, true, pts12Add, pts03Add);
                        }
                        else
                        {
                            if (shortsideLength > _bmp.Width)
                            {
                                float longsideLength = shortsideLength;
                                shortsideLength = _bmp.Width;
                                PointF[] pts = new PointF[4];
                                double v = (longsideLength - shortsideLength) / 2.0D;
                                if (pm == PerspectiveModus.VerticalDownMode2)
                                {
                                    pts[3] = new PointF(0, _bmp.Height);
                                    pts[2] = new PointF(longsideLength, _bmp.Height);
                                    pts[0] = new PointF((float)v, 0);
                                    pts[1] = new PointF(longsideLength - (float)v, 0);
                                }
                                else
                                {
                                    pts[0] = new PointF(0, _bmp.Height);
                                    pts[1] = new PointF(longsideLength, _bmp.Height);
                                    pts[3] = new PointF((float)v, 0);
                                    pts[2] = new PointF(longsideLength - (float)v, 0);
                                }
                                if (pm == PerspectiveModus.VerticalDownMode2)
                                    _bmp.RotateFlip(RotateFlipType.RotateNoneFlipY);
                                bmp = fipbmp.PerspectiveMode2(_bmp, pm, shortsideLength, longsideLength, true, true, pts12Add, pts03Add, pts);
                                if (pm == PerspectiveModus.VerticalDownMode2)
                                    bmp.RotateFlip(RotateFlipType.RotateNoneFlipY);
                            }
                            else
                                bmp = fipbmp.PerspectiveMode2(_bmp, pm, shortsideLength, true, true, pts12Add, pts03Add);
                        }

                        if (_bmp != null)
                            _bmp.Dispose();
                        _bmp = bmp;

                        if (this.checkBox2.Checked)
                        {
                            Bitmap bmp4 = fipbmp.ScanForPic(_bmp);

                            if (bmp4 != null)
                            {
                                if (_bmp != null)
                                    _bmp.Dispose();
                                _bmp = bmp4;
                            }
                        }

                        this.Cursor = Cursors.Default;
                        _pic_changed = true;

                        CalculateZoom();

                        this.panel2.AutoScrollMinSize = new Size((int)(_bmp.Width * _zoom), (int)(_bmp.Height * _zoom));
                        this.panel2.Invalidate();
                    }
                    catch
                    {
                        if (bmp != null)
                            bmp.Dispose();
                    }
                }
            }
        }

        private void CalculateZoom()
        {
            if (this._zoom != 1.0F)
            {
                double faktor = (double)panel2.Width / (double)panel2.Height;
                double multiplier = (double)_bmp.Width / (double)_bmp.Height;
                if (multiplier >= faktor)
                    _zoom = (float)((double)panel2.Width / (double)_bmp.Width);
                else
                    _zoom = (float)((double)panel2.Height / (double)_bmp.Height);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.comboBox1.SelectedItem = this.comboBox1.Items[0];

            foreach (string z in Enum.GetNames(typeof(PerspectiveModus)))
            {
                if(z.Contains("Mode2"))
                    this.comboBox2.Items.Add(z);
            }

            this.comboBox2.Sorted = true;
            this.comboBox2.SelectedItem = this.comboBox2.Items[0];

            this.comboBox3.Items.AddRange(new object[] { 0.25f, 0.5f, 0.75f, "Custom" });
            this.comboBox3.SelectedItem = this.comboBox3.Items[0];
            this.comboBox4.SelectedItem = this.comboBox4.Items[0];

            foreach (string z in Enum.GetNames(typeof(WaveModus)))
            {
                this.comboBox5.Items.Add(z);
            }

            this.comboBox5.Sorted = false;
            this.comboBox5.SelectedItem = this.comboBox5.Items[0];

            this.comboBox6.SelectedItem = this.comboBox6.Items[0];
        }

        private void panel2_Click(object sender, EventArgs e)
        {
            panel2.Focus();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            if (_bmp != null)
            {
                Panel pz = (Panel)sender;
                Graphics g = e.Graphics;
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = PixelOffsetMode.Half;
                g.DrawImage(_bmp,
                    new RectangleF(0, 0, pz.DisplayRectangle.Width, pz.DisplayRectangle.Height),
                    new RectangleF(-pz.AutoScrollPosition.X / _zoom, -pz.AutoScrollPosition.Y / _zoom, pz.DisplayRectangle.Width / _zoom, pz.DisplayRectangle.Height / _zoom),
                    GraphicsUnit.Pixel);
            }
        }

        private void panel2_DoubleClick(object sender, EventArgs e)
        {
            if (_bmp != null)
            {
                if (this._zoom != 1.0F)
                {
                    this._zoom = 1.0F;
                }
                else
                {
                    double faktor = (double)panel2.Width / (double)panel2.Height;
                    double multiplier = (double)_bmp.Width / (double)_bmp.Height;
                    if (multiplier >= faktor)
                        _zoom = (float)((double)panel2.Width / (double)_bmp.Width);
                    else
                        _zoom = (float)((double)panel2.Height / (double)_bmp.Height);
                }
                this.panel2.AutoScrollMinSize = new Size((int)(_bmp.Width * _zoom), (int)(_bmp.Height * _zoom));
                this.panel2.Invalidate();
            }
        }

        private void panel2_DragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
            }
        }

        private void panel2_DragDrop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop)) //typeof(Html_Tool.PictureContainer)))
            {
                if (e.Effect == DragDropEffects.Copy)
                {
                    try
                    {
                        if (_pic_changed)
                        {
                            DialogResult dlg = MessageBox.Show("Bild erst noch speichern?", "Ungespeichert Daten",
                                MessageBoxButtons.YesNoCancel, MessageBoxIcon.Exclamation);

                            if (dlg == DialogResult.Yes)
                            {
                                button2.PerformClick();
                            }
                            else if (dlg == DialogResult.No)
                                _pic_changed = false;
                        }

                        String[] files = (String[])e.Data.GetData(DataFormats.FileDrop);
                        Image img = Image.FromFile(files[0]);
                        if (_bmp != null)
                            _bmp.Dispose();
                        _bmp = new Bitmap((Bitmap)img.Clone());
                        img.Dispose();

                        this.numericUpDown1.Value = (decimal)_bmp.Width;
                        this.numericUpDown2.Value = (decimal)_bmp.Height;

                        this.Text = files[0];
                        _pic_changed = false;

                        this._zoom = 1.0F;
                        this.panel2.AutoScrollMinSize = new Size((int)(_bmp.Width * _zoom), (int)(_bmp.Height * _zoom));
                        this.panel2.Invalidate();
                    }
                    catch
                    {
                        MessageBox.Show("Fehler beim Laden des Bildes");
                    }
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (Control ct in this.panel1.Controls)
                ct.Enabled = false;

            this.button1.Enabled = this.button2.Enabled = true;
            this.label1.Enabled = this.label3.Enabled = this.label6.Enabled = this.label7.Enabled = true;
            this.comboBox1.Enabled = true;
            this.button7.Enabled = this.checkBox2.Enabled = true;
            this.button6.Enabled = this.button8.Enabled = true;
            this.numericUpDown10.Enabled = this.numericUpDown11.Enabled = true;
            this.comboBox6.Enabled = true;

            if (this.Visible)
            {
                if (this.comboBox1.SelectedIndex == 0)
                {
                    this.label2.Enabled = this.label4.Enabled = this.label5.Enabled = this.label8.Enabled = true;
                    this.numericUpDown4.Enabled = this.numericUpDown5.Enabled = this.numericUpDown3.Enabled = true;
                    this.comboBox2.Enabled = this.comboBox3.Enabled = this.comboBox4.Enabled = true;
                    this.button3.Enabled = this.button5.Enabled = true;
                    this.CheckBox1.Enabled = this.numericUpDown9.Enabled = true;
                }
                else
                {
                    this.label9.Enabled = this.label10.Enabled = this.label11.Enabled = this.label12.Enabled = true;
                    this.numericUpDown6.Enabled = this.numericUpDown7.Enabled = this.numericUpDown8.Enabled = true;
                    this.comboBox5.Enabled = true;
                    this.button4.Enabled = true;
                }
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox t = (ComboBox)sender;
            if (t.SelectedIndex < 2)
            {
                this.numericUpDown1.Enabled = false;
                this.numericUpDown2.Enabled = true;
            }
            else
            {
                this.numericUpDown1.Enabled = true;
                this.numericUpDown2.Enabled = false;
            }

            if (t.SelectedIndex >= 2)
            {
                this.label6.Text = "left";
                this.label7.Text = "right";
            }
            else
            {
                this.label6.Text = "top";
                this.label7.Text = "bottom";
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox t = (ComboBox)sender;

            if (t.SelectedIndex < 3)
                this.numericUpDown3.Visible = false;
            else
                this.numericUpDown3.Visible = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (_bmp != null)
            {
                Matrix mx = null;
                Bitmap bmp = null;

                try
                {
                    if (comboBox4.SelectedIndex < 1)
                    {
                        if (comboBox3.SelectedIndex < 3)
                        {
                            mx = new Matrix(float.Parse(comboBox3.SelectedItem.ToString()), 0f, 0f, 1f, 0f, 0f);
                            bmp = new Bitmap((int)Math.Ceiling((float)_bmp.Width * float.Parse(comboBox3.SelectedItem.ToString())), _bmp.Height);
                        }
                        else
                        {
                            mx = new Matrix((float)this.numericUpDown3.Value, 0f, 0f, 1f, 0f, 0f);
                            bmp = new Bitmap((int)Math.Ceiling((float)_bmp.Width * (float)this.numericUpDown3.Value), _bmp.Height);
                        }
                    }
                    else
                    {
                        if (comboBox3.SelectedIndex < 3)
                        {
                            mx = new Matrix(1f, 0f, 0f, float.Parse(comboBox3.SelectedItem.ToString()), 0f, 0f);
                            bmp = new Bitmap(_bmp.Width, (int)Math.Ceiling((float)_bmp.Height * float.Parse(comboBox3.SelectedItem.ToString())));
                        }
                        else
                        {
                            mx = new Matrix(1f, 0f, 0f, (float)this.numericUpDown3.Value, 0f, 0f);
                            bmp = new Bitmap(_bmp.Width, (int)Math.Ceiling((float)_bmp.Height * (float)this.numericUpDown3.Value));
                        }
                    }
                }
                catch
                {

                }

                if (bmp != null)
                {
                    Graphics g = null;

                    try
                    {
                        g = Graphics.FromImage(bmp);
                        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                        g.Transform = mx;
                        g.DrawImage(_bmp, 0f, 0f);
                        g.Dispose();
                    }
                    catch
                    {
                        if (g != null)
                            g.Dispose();
                    }

                    if (_bmp != null)
                        _bmp.Dispose();
                    _bmp = bmp;

                    _pic_changed = true;

                    CalculateZoom();

                    this.panel2.AutoScrollMinSize = new Size((int)(_bmp.Width * _zoom), (int)(_bmp.Height * _zoom));
                    this.panel2.Invalidate();
                }
                else
                {
                    MessageBox.Show("Fehler.");
                }
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_pic_changed)
            {
                DialogResult dlg = MessageBox.Show("Bild erst noch speichern?", "Ungespeichert Daten",
                    MessageBoxButtons.YesNoCancel, MessageBoxIcon.Exclamation);

                if (dlg == DialogResult.Yes)
                {
                    button2.PerformClick();
                }
                else if (dlg == DialogResult.Cancel)
                    e.Cancel = true;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (_bmp != null)
            {
                this.Cursor = Cursors.WaitCursor;
                Application.DoEvents();

                WaveModus wm = (WaveModus)Enum.Parse(typeof(WaveModus), this.comboBox5.SelectedItem.ToString());
                float wh = (float)this.numericUpDown6.Value;
                Double hw = (double)this.numericUpDown7.Value;
                float lr = (float)this.numericUpDown8.Value;

                Bitmap bmp = fipbmp.Wave(_bmp, wm, wh, hw, lr, true);

                if (bmp != null)
                {
                    this.Cursor = Cursors.Default;

                    if (_bmp != null)
                        _bmp.Dispose();
                    _bmp = bmp;

                    _pic_changed = true;

                    CalculateZoom();

                    this.panel2.AutoScrollMinSize = new Size((int)(_bmp.Width * _zoom), (int)(_bmp.Height * _zoom));
                    this.panel2.Invalidate();
                }
                else
                {
                    MessageBox.Show("Fehler.");
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (_bmp != null)
            {
                Bitmap bmp4 = fipbmp.ScanForPic(_bmp);

                if (bmp4 != null)
                {
                    if (_bmp != null)
                        _bmp.Dispose();
                    _bmp = bmp4;

                    _pic_changed = true;

                    CalculateZoom();

                    this.panel2.AutoScrollMinSize = new Size((int)(_bmp.Width * _zoom), (int)(_bmp.Height * _zoom));
                    this.panel2.Invalidate();
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (_bmp != null)
            {
                if (this.comboBox2.SelectedIndex < 2)
                {
                    LookUpValues lv = fipbmp.GetLongestVert(_bmp);
                    LookUpValues sv = fipbmp.GetShortestVert(_bmp);
                    this.numericUpDown11.Value = (decimal)lv.Laenge;
                    this.numericUpDown10.Value = (decimal)sv.Laenge;
                    if (lv.Pos > sv.Pos)
                        this.comboBox6.SelectedIndex = 0;
                    else
                        this.comboBox6.SelectedIndex = 1;
                }
                else
                {
                    LookUpValues lh = fipbmp.GetLongestHorz(_bmp);
                    LookUpValues sh = fipbmp.GetShortestHorz(_bmp);
                    this.numericUpDown11.Value = (decimal)lh.Laenge;
                    this.numericUpDown10.Value = (decimal)sh.Laenge;
                    if (lh.Pos > sh.Pos)
                        this.comboBox6.SelectedIndex = 0;
                    else
                        this.comboBox6.SelectedIndex = 1;
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (_bmp != null)
            {
                Bitmap bmp = null;
                try
                {
                    if (this.comboBox2.SelectedIndex < 2)
                    {
                        int lv = (int)this.numericUpDown11.Value;
                        int sv = (int)this.numericUpDown10.Value;
                        if (this.comboBox6.SelectedIndex == 0)
                            _bmp.RotateFlip(RotateFlipType.RotateNoneFlipX);
                        _bmp.RotateFlip(RotateFlipType.Rotate90FlipNone);
                        bmp = fipbmp.MakeRectangular(_bmp, lv, sv);

                        if (bmp != null)
                        {
                            bmp.RotateFlip(RotateFlipType.Rotate270FlipNone);
                            if (this.comboBox6.SelectedIndex == 0)
                                bmp.RotateFlip(RotateFlipType.RotateNoneFlipX);
                            _bmp.Dispose();
                            _bmp = bmp;
                        }
                        else
                        {
                            MessageBox.Show("Fehler.");
                        }
                    }
                    else
                    {
                        int lh = (int)this.numericUpDown11.Value;
                        int sh = (int)this.numericUpDown10.Value;
                        if (this.comboBox6.SelectedIndex == 0)
                            _bmp.RotateFlip(RotateFlipType.RotateNoneFlipY);
                        bmp = fipbmp.MakeRectangular(_bmp, lh, sh);

                        if (bmp != null)
                        {
                            if (this.comboBox6.SelectedIndex == 0)
                                bmp.RotateFlip(RotateFlipType.RotateNoneFlipY);
                            _bmp.Dispose();
                            _bmp = bmp;
                        }
                        else
                        {
                            MessageBox.Show("Fehler.");
                        }
                    }

                    _pic_changed = true;

                    CalculateZoom();

                    this.panel2.AutoScrollMinSize = new Size((int)(_bmp.Width * _zoom), (int)(_bmp.Height * _zoom));
                    this.panel2.Invalidate();
                }
                catch
                {
                    if (bmp != null)
                        bmp.Dispose();
                }
            }
        }
    }
}
