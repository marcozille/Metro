'Lizenz: Frei, bzw. siehe Beispielcodelizenzen
'
'Wird as-is bereitgestellt, �bernehme keinerlei Garantien, weder f�r Datenverlust, noch sonstwelche Sch�den,
'die mittel- oder unmittelbar durch diese Software entstehen. Ebensowenig f�r Vollst�ndigkeit und Fehlerfreiheit.

'Dies ist/sind Testprogramm/e.
'Bitte mit vern�nftigen Werten benutzen, keine Riesenbilder, da nicht alle Fehler abgefangen werden.

 - Programme geschrieben von Thorsten Gudera, Aragorn257@gmx.de

##################################################################################

- PROVIDED AS-IS WITH NO WARRANTIES OF ANY KIND

##################################################################################